public class Name {

    private String fname;
    private String lname;
    private String mname;

    //constructor
    //no return, name same as class
    public Name() {

    }

    public Name(String fname, String mname, String lname){
        this.fname = fname;
        this.mname = mname;
        this.lname = lname;
    }

    public void setFname(String fname){
        // "this" refers to the class attributes
        this.fname = fname;
    }

    public String getFname(){
        return fname;
    }

    public void setMname(String mname){
        // "this" refers to the class attributes
        this.mname = mname;
    }

    public void setLname(String lname){
        // "this" refers to the class attributes
        this.lname = lname;
    }
}
