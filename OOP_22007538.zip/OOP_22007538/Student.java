// created by team in KL
public class Student {
    // data/attributes
    Name name;
    String ic;
    String address;
    String schoolname;
    float marks[] = new float[5];

    // methods or operations
    float calcAvg() {
        return 0;
    }

    float calcMin() {
        return 0;
    }

    void setName(Name name) {
        this.name=name;
    }

    void setMark(float mark, int i) {
        marks[i] = mark;
    }

}