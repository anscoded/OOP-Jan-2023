// createed by team in Bangalore
public class Teacher {
    // data
    String name;
    String ic;
    String address;
    int numyearexp;
    String qualification;

    // op


}
